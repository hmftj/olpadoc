<?php
define('DB_SERVER','sunsecurities.pk');
define('DB_USER','sunsecur_hmftj');
define('DB_PASS' ,'xyz');
define('DB_NAME', 'sunsecur_olpadoc');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>